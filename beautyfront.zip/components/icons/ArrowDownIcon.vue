<template>
  <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M6.17505 9.2625L1.30005 4.3875L2.43755 3.25L6.17505 6.9875L9.91255 3.25L11.05 4.3875L6.17505 9.2625Z" fill="#141414"/>
  </svg>
</template>
