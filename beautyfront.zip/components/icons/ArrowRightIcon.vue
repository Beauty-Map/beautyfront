<template>
  <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M6.66235 1.21289L1.33105 6.99997L6.66235 12.787" stroke="#828282"/>
  </svg>
</template>
