<template>
  <svg width="39" height="39" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g filter="url(#filter0_i_556_2901)">
      <path d="M19.4999 35.75C10.5461 35.75 3.24988 28.4538 3.24988 19.5C3.24988 10.53 10.5461 3.25 19.4999 3.25L19.9545 3.25624C28.7146 3.49726 35.7499 10.682 35.7499 19.5C35.7499 28.4538 28.4699 35.75 19.4999 35.75ZM21.8399 26.3575C22.1649 26.3575 22.4736 26.2437 22.7174 26C23.1886 25.5125 23.1886 24.7487 22.7011 24.2775L17.9074 19.5L22.7011 14.7225C23.1886 14.2513 23.1886 13.4713 22.7174 13C22.2299 12.5125 21.4661 12.5125 20.9949 13L15.3236 18.6388C15.0961 18.8663 14.9661 19.175 14.9661 19.5C14.9661 19.825 15.0961 20.1337 15.3236 20.3612L20.9949 26C21.2224 26.2437 21.5311 26.3575 21.8399 26.3575Z" fill="#FF3CA0"/>
    </g>
    <defs>
      <filter id="filter0_i_556_2901" x="3.24988" y="3.25" width="34.5" height="35.5" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
        <feFlood flood-opacity="0" result="BackgroundImageFix"/>
        <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
        <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
        <feOffset dx="2" dy="3"/>
        <feGaussianBlur stdDeviation="3.25"/>
        <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
        <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"/>
        <feBlend mode="normal" in2="shape" result="effect1_innerShadow_556_2901"/>
      </filter>
    </defs>
  </svg>
</template>
