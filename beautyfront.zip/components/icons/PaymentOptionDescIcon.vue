<template>
  <svg width="26" height="18" viewBox="0 0 26 18" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M1 1H25" stroke="#133C3E" stroke-width="2" stroke-linecap="round"/>
    <path d="M1 17H25" stroke="#133C3E" stroke-width="2" stroke-linecap="round"/>
    <path d="M1 9H25" stroke="#133C3E" stroke-width="2" stroke-linecap="round"/>
    <path d="M25 5L9 5" stroke="#133C3E" stroke-width="2" stroke-linecap="round"/>
    <path d="M25 13L9 13" stroke="#133C3E" stroke-width="2" stroke-linecap="round"/>
  </svg>
</template>
