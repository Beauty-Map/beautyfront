<template>
  <svg width="31" height="32" viewBox="0 0 31 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <ellipse cx="11.6249" cy="18.6668" rx="5.16667" ry="5.33333" stroke="#133C3E" stroke-width="1.5"/>
    <path d="M15.5 14.6667L20.0208 10M21.9583 8L20.0208 10M20.0208 10L23.25 13.3333" stroke="#133C3E" stroke-width="1.5" stroke-linecap="round"/>
  </svg>
</template>
