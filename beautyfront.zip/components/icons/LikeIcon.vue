<template>
  <img src="/images/portfolio/like_icon.png" alt=""/>
</template>
