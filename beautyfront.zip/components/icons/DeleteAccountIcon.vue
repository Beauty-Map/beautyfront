<template>
  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M1 19V18C1 15.7909 2.79086 14 5 14H9C11.2091 14 13 15.7909 13 18V19" stroke="#133C3E" stroke-width="2" stroke-linecap="round"/>
    <path d="M7 11C5.34315 11 4 9.6569 4 8C4 6.34315 5.34315 5 7 5C8.6569 5 10 6.34315 10 8C10 9.6569 8.6569 11 7 11Z" stroke="#133C3E" stroke-width="2" stroke-linecap="round"/>
    <path d="M13 1L19 7" stroke="#133C3E" stroke-width="2" stroke-linecap="round"/>
    <path d="M19 1L13 7" stroke="#133C3E" stroke-width="2" stroke-linecap="round"/>
  </svg>
</template>
