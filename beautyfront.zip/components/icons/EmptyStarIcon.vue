<template>
  <svg width="12" height="13" viewBox="0 0 12 13" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M6 10.1442L9.708 12.5L8.724 8.06L12 5.07263L7.686 4.68737L6 0.5L4.314 4.68737L0 5.07263L3.276 8.06L2.292 12.5L6 10.1442Z" fill="#C0C0C0"/>
  </svg>
</template>
