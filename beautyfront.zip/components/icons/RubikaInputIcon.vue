<template>
  <svg width="39" height="39" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g filter="url(#filter0_d_600_3283)">
      <rect x="8" y="6" width="23" height="23" fill="url(#pattern0_600_3283)" shape-rendering="crispEdges"/>
    </g>
    <defs>
      <filter id="filter0_d_600_3283" x="0" y="0" width="39" height="39" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
        <feFlood flood-opacity="0" result="BackgroundImageFix"/>
        <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
        <feOffset dy="2"/>
        <feGaussianBlur stdDeviation="4"/>
        <feComposite in2="hardAlpha" operator="out"/>
        <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"/>
        <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_600_3283"/>
        <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_600_3283" result="shape"/>
      </filter>
      <pattern id="pattern0_600_3283" patternContentUnits="objectBoundingBox" width="1" height="1">
        <use xlink:href="#image0_600_3283" transform="scale(0.011236)"/>
      </pattern>
      <image id="image0_600_3283" width="89" height="89" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFkAAABZCAMAAABi1XidAAABfVBMVEVHcEzh4eHh4eHh4eHk5OTl5eXk5OT29/fm5ubr6+vj4+PW4OHk5OTi4uL////k5OTg4ODx8fF5Q4dMNoP2qSXvdBTnS1C4zgF9tCQPaKA1rJ1JvcpZ1r3yjhz+/v7w8O/8/PvoT1RSOoX7+vGukrW+zAcrkbREvquil72wygWzywODtyyEth/30Z3n5+duQIbt8bpfPobPwBGs0HX36djpV0TvcxnrYDL+8uad19Xr9fZ3tDGTwUn63sLt7upavLNSs35PuKfwrSLuayLVSlg2TJD2rTDwpGpnncHnsh1ktWL0tULxfiT2wGCfRG5tOnf3s4p5S4ocYJzDR1+31uDU3OJyYpRnkqR7tCdvtEbzl1DC1SLb6sLyjTeQRXtY1bxTv8uQ5NNZ0LreuRm+6eI7rJDR31bW4mnS8uxx3MfI2TgvfK1vx9B8syTf6Y7ra2/T5rSxR2lMvcTe7tuKucxvxLnH36JZx8O/0xmnnMLwkZSmmb2QY5s6mbOkmb5PNzedAAAADnRSTlMA821WzNTw/hXwk/I4j6MKgpQAAAWkSURBVFjDtdnpV9NKFADwFoppOceULiGlpZPQWBVrpNJSSxda9k1ERbQgi4iCW33u5z3Pe/7tbyZJ05mkk0yg3M/xd8Z7Z+jMvT6fHsHB6wH/yGXDH7g+GPQRMRC4FuEAf9mQOelaYABzg0Mhvn8RGjKXHfRzfYQB4PzBDsz3NwBv0EMc3+/ghrTihfoO8yA0gKrHX0XAKg6GrkQODfqGI2yfKvnzl2KuVjhQmD6Xhn0BpvqB/IesKN65m0jkal9YThQX8PkBi3sGXV2GUTiQ3U+j3zfCkIhzzTXldq4w5/qPRlxloHx+KYqk3G7XXG1XWc6brikjO5H7pVxG1gtnlxOJVs6llI4yKJ7jLiFDO5ErfAcXkYHy+PDUQU60q835k4p3WVEPhXR8YTpLk6sbb5O3xt+/4TzK9UNBgHIc2r3kdmvvbTIJ5fHx9+88yKC4+lAw5Hh8fdomt/aayaQhH4+fvAOMsvJYczsytMmT0qrqri6jOOFYZFk9FARSji+cYqe72nybtMgw3bKbDOr7gmCTYUzrf5HaqHBJm4zSLTvKZiJsMirlnbst3CVka0ossrIqCDQZlXKvmUxS5XFic5MyIGGrvFl/M+8kj5/INLk4s0iXN9Uyz1dm5+ly48UuTf49OvqgRJG3yvp/q/Kzt3z8+sWT6A2KDKA8OoPZXXmrLnduQPKbhl2G7vNoNPovbc0ToyhmFksWeVMldpRspqQjv24gNxp94iwjG5dX1LL19Fdmcfm48fxJlE2G6V7syCtbxV63wnc/Dfn4uPHCcGG4y3op02ingd6XQh7tQCi/xlw2GZUyvak6/NjBHXhLL5xHGcZq2fkyUvlBuqzyztGNOacXBpC5P5kp7/LSo2j0Rjg8Jzu8SSK3Y7H7XuWv6Dso02zARWBAmbTd5Imdo6gph8MRu81FJFOOYSlxkZeOjO8MGdqATHBEhw0Zsx1llGCrHMZKCQsX6URHjmXuT7nKX7GsdeVw+J6MjgfgZWO5pAxjylneOYpS5PC9ORmg9WIwIWspoclYIuwyDImLkEHIaJfQZMu2t8n3JGc5dkSTM5YjZZXDjnJme2eCKhN706O8vQMPgoMMkzV1EXn70dKom4wdV2Y588g4vC4y3Pee5Iy2Xia5s+/Z5O0l8+8Yi6yVkkVGhfMmo1K6yn+2vxI/FoxyLLa26ywXVy0/b4zy8tObr2Z36XJR3UyXHniXl5+Ojd1MpV7N9pYlSV2Jx9OCUJrxKENXk1OpT896yJK6ha5PaXTfWZzxIGuuIeO2IUv1Lf3Cl9ZvaQ9m3OT73UTgcurVp11MlopbK3FCFox0T1Dl54TblVG6dztyUV0xL79p80Ksp+QvmvxPNxEW2SilFJEwF5ehDeXfNHk3szw2RpFRukfm1E3i5YLLMCUTdZosr405yKnUT9K1yIKwr1BfbZU1B7mxkbszveAg75cdXpokjcvfmtVEYlLMntLkEgH3eB0/+9hTnt9rJZAsitn1nvKhKru8u3nux0ebPL/RaicMWRSn123yw8dlhi4EMFNiyN82qkZfQ5fFbCfdhlxaLQKW/gb86NlaV/7W3DM7PJOdHkr2dMGUS/t12UO3R0s3kht7WO9ostv50dKN5IcqfGp5kEEFpvsm3GnVRG8ZpmQdyvYEM/TrKmv/Natmc84mo5SkV8sX6gTK3ws53LXK4llevmD3EoCDWo6WDfFD/sLdS7RNlC+13mt++VnhLyFrTcxfNfuakevWJfbLbiMdoBRyFvnceb16z5ypz98ppSZnz/LuHXwu4BuWmGYNeikntcIxzSauM89TlINCLTf591mebepxbZB9BgS0MwwYh4iB4NXMrfiQNn4M9H3WBmD9rmQ+yPPd0WN/V23ONCEd6OscNoCPjweGQhInXxqVOSk0NECOpYODw32Zdw+b8+7/Aab8hus94bCGAAAAAElFTkSuQmCC"/>
    </defs>
  </svg>
</template>
