<script setup lang="ts">

</script>

<template>
  <div class="w-full bg-[#FF3CA0] h-[1px]"></div>
</template>

<style scoped>

</style>