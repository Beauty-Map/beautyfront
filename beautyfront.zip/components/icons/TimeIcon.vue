<template>
  <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="7.5" cy="7.5" r="5.5" fill="#085EC2" stroke="white"/>
    <path d="M10.3125 7.5H7.75C7.61193 7.5 7.5 7.38807 7.5 7.25V5.3125" stroke="white" stroke-linecap="round"/>
  </svg>
</template>
