<template>
  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M17.5 15V13.3333H12.5V15H17.5ZM17.5 10.8333V9.16667H7.5V10.8333H17.5ZM17.5 6.66667V5H2.5V6.66667H17.5Z" fill="#141414"/>
  </svg>
</template>
