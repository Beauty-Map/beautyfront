<template>
  <svg width="39" height="40" viewBox="0 0 39 40" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g filter="url(#filter0_d_600_3284)">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M14.5714 6.00006H24.4286C28.0432 6.00006 31 8.95265 31 12.567V15.7362C27.7597 17.1927 24.491 24.3863 19.7268 22.8232C19.3344 23.1021 18.43 24.2512 18.3665 25.1231C16.7168 24.9034 14.8149 23.0128 15.0431 20.9741C12.2973 18.9879 14.5648 15.3215 16.7422 13.8458C21.409 10.6829 27.8878 13.4031 24.284 15.6645C22.0927 17.0397 17.4066 17.948 17.8938 14.5722C16.6083 14.943 15.7855 17.3399 17.3332 18.5889C15.8995 19.9975 16.1751 22.5868 17.7077 23.437C19.2576 19.4211 24.6522 19.9459 26.8318 15.1521C28.4717 11.546 26.0404 7.43715 21.1795 8.06834C17.511 8.54475 14.0723 11.6393 12.3526 15.3096C10.6077 19.0334 10.8674 24.02 14.4503 26.5331C18.6669 29.4905 23.156 26.7521 25.8749 23.1729C27.4775 21.0633 28.8778 18.7263 31 17.3765V22.9955C31 26.6098 28.0428 29.5714 24.4286 29.5714H14.5714C10.9571 29.5714 8 26.6143 8 23V12.5714C8 8.95714 10.9571 6 14.5714 6V6.00006Z" fill="#EE7F22"/>
    </g>
    <defs>
      <filter id="filter0_d_600_3284" x="0" y="0" width="39" height="39.5713" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
        <feFlood flood-opacity="0" result="BackgroundImageFix"/>
        <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
        <feOffset dy="2"/>
        <feGaussianBlur stdDeviation="4"/>
        <feComposite in2="hardAlpha" operator="out"/>
        <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"/>
        <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_600_3284"/>
        <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_600_3284" result="shape"/>
      </filter>
    </defs>
  </svg>
</template>
