<script setup lang="ts">

</script>

<template>
  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M6.5 5V1.5L2 7H5.5V10.5L10 5H6.5Z" stroke="#1EFF81" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
</template>

<style scoped>

</style>