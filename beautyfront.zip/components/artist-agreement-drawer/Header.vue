<template>
  <div class="w-full flex flex-col justify-start items-start px-[32px] py-[24px] border-b border-b-[#D9D9D9]">
    <span class="text-right text-[#9F9F9F] font-medium text-[16px] leading-[24px]">توافق نامه</span>
    <span class="mt-[6px] text-right text-[#494949] font-semibold text-[22px] leading-[34px]">و شرایط استفاده از خدمات</span>
    <span class="mt-[6px] text-right text-[#7C7C7C] font-semibold text-[16px] leading-[24px]">آخرین بروزرسانی 1/1/1403</span>
  </div>
</template>
<script setup lang="ts">
</script>