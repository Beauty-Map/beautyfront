<template>
  <div class="w-full flex flex-col justify-center items-center">
    <div class="w-full font-semibold text-[16px] leading-[24px] text-[#141414] text-center">
      امنیت
    </div>
  </div>
</template>

<script setup lang="ts">
</script>

<style scoped>

</style>