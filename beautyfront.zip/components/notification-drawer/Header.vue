<template>
  <div class="w-full text-center text-[#141414] text-base font-medium">
    نوتفیکیشن
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>