<template>
  <div class="w-full flex flex-col items-start justify-start">
    <MainTitle :title="'خدمات'" class="mb-[8px]"/>
    <ServiceGrid />
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>