<script setup lang="ts">

</script>

<template>
  <svg width="73" height="70" viewBox="0 0 73 70" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="14" width="45" height="3" rx="1.5" fill="#FFEA2E"/>
    <path d="M0 70L15 0H58.5L73 70H0Z" fill="url(#paint0_linear_1122_955)"/>
    <defs>
      <linearGradient id="paint0_linear_1122_955" x1="34" y1="0" x2="34" y2="70" gradientUnits="userSpaceOnUse">
        <stop stop-color="#F8F7FC" stop-opacity="0.5"/>
        <stop offset="1" stop-color="#F8F7FC" stop-opacity="0"/>
      </linearGradient>
    </defs>
  </svg>
</template>

<style scoped>

</style>