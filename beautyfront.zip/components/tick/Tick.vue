<template>
  <BronzeTick />
</template>

<script setup lang="ts">

import BronzeTick from "~/components/icons/BronzeTick.vue";
</script>

<style scoped>

</style>