<template>
  <div class="w-full flex flex-col justify-start items-start py-[13px] px-[20px]">
    <img src="/panel/artist_agree_result.png" />
  </div>
</template>
