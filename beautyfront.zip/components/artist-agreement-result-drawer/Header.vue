<template>
  <div class="w-full flex flex-col justify-center items-start px-[50px] pt-[96px]">
    <h3 class="text-[#141414] text-center font-semibold text-[18px] leading-[28px]">اطلاعات شما با موفقیت دریافت شد</h3>
    <div class="w-full text-right font-medium text-[#828282] text-[14px] leading-[21px] mt-[18px] -mb-[10px]">
      <p>
        بعد بازبینی پشتیبان و تاییدیه شما به عنوان هنرمند حساب کاربری شما فعال میشود.
        <br>
        نکته: این عمل ممکن است تا 72 ساعت زمان بر باشد.
      </p>
    </div>
  </div>
</template>
<script setup lang="ts">
</script>