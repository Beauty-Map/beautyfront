<template>
  <div class="flex flex-col justify-center items-center">
    <div class="font-medium text-[24px] leading-[37px] text-[#141414] text-center">
      عضویت
    </div>
    <div class="font-medium text-[13px] leading-[18px] text-[#133C3E] text-center mx-7">
      برای ثبت نام در بیوتی مپ  شماره خود را وارد کنید
    </div>
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>