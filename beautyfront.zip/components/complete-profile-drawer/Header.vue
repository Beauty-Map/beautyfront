<template>
  <div class="flex flex-col justify-center items-center">
    <ProfileBigIcon />
  </div>
</template>

<script setup lang="ts">
import ProfileBigIcon from "~/components/icons/ProfileBigIcon.vue";
</script>

<style scoped>

</style>