<template>
  <div class="cursor-pointer absolute top-[28px] right-[28px] text-black text-[16px] leading-[24px] font-medium">ادامه</div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>