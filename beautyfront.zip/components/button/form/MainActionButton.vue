<template>
  <div class="cursor-pointer flex flex-row justify-center items-center rounded-[20px] bg-[#FF3CA0] h-[48px] w-full">
    <slot></slot>
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>