<template>
  <svg class="cursor-pointer" width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
    <mask id="path-1-inside-1_162_622" fill="white">
      <rect x="0.5" y="0.5" width="28" height="28" rx="3"/>
    </mask>
    <rect x="0.5" y="0.5" width="28" height="28" rx="3" stroke="black" stroke-width="28" mask="url(#path-1-inside-1_162_622)"/>
    <path d="M12.1666 9.83325L23.8333 9.83325" stroke="white" stroke-linecap="round"/>
    <path d="M5.16663 19.1667L16.8333 19.1667" stroke="white" stroke-linecap="round"/>
    <ellipse cx="8.66663" cy="9.83325" rx="3.5" ry="3.5" transform="rotate(90 8.66663 9.83325)" stroke="white" stroke-linecap="round"/>
    <ellipse cx="20.3334" cy="19.1667" rx="3.5" ry="3.5" transform="rotate(90 20.3334 19.1667)" stroke="white" stroke-linecap="round"/>
  </svg>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>