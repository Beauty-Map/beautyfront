export default defineEventHandler((event) => {
    return [
        {
            id: 1,
            title: 'بیوتی مپ',
            description: 'تخفیف ویژه زهرا زارعی تا...',
            created_at_ago_fa: '12 دقیقه پیش'
        },
        {
            id: 2,
            title: 'بیوتی مپ',
            description: 'تخفیف ویژه زهرا زارعی تا...',
            created_at_ago_fa: '12 دقیقه پیش'
        },
        {
            id: 3,
            title: 'بیوتی مپ',
            description: 'تخفیف ویژه زهرا زارعی تا...',
            created_at_ago_fa: '12 دقیقه پیش'
        },
        {
            id: 4,
            title: 'بیوتی مپ',
            description: 'تخفیف ویژه زهرا زارعی تا...',
            created_at_ago_fa: '12 دقیقه پیش'
        },
        {
            id: 5,
            title: 'بیوتی مپ',
            description: 'تخفیف ویژه زهرا زارعی تا...',
            created_at_ago_fa: '12 دقیقه پیش'
        },
        {
            id: 6,
            title: 'بیوتی مپ',
            description: 'تخفیف ویژه زهرا زارعی تا...',
            created_at_ago_fa: '12 دقیقه پیش'
        },
        {
            id: 7,
            title: 'بیوتی مپ',
            description: 'تخفیف ویژه زهرا زارعی تا...',
            created_at_ago_fa: '12 دقیقه پیش'
        },
        {
            id: 8,
            title: 'بیوتی مپ',
            description: 'تخفیف ویژه زهرا زارعی تا...',
            created_at_ago_fa: '12 دقیقه پیش'
        },
        {
            id: 9,
            title: 'بیوتی مپ',
            description: 'تخفیف ویژه زهرا زارعی تا...',
            created_at_ago_fa: '12 دقیقه پیش'
        },
        {
            id: 10,
            title: 'بیوتی مپ',
            description: 'تخفیف ویژه زهرا زارعی تا...',
            created_at_ago_fa: '12 دقیقه پیش'
        },
        {
            id: 11,
            title: 'بیوتی مپ',
            description: 'تخفیف ویژه زهرا زارعی تا...',
            created_at_ago_fa: '12 دقیقه پیش'
        },
        {
            id: 12,
            title: 'بیوتی مپ',
            description: 'تخفیف ویژه زهرا زارعی تا...',
            created_at_ago_fa: '12 دقیقه پیش'
        },
        {
            id: 13,
            title: 'بیوتی مپ',
            description: 'تخفیف ویژه زهرا زارعی تا...',
            created_at_ago_fa: '12 دقیقه پیش'
        },
        {
            id: 14,
            title: 'بیوتی مپ',
            description: 'تخفیف ویژه زهرا زارعی تا...',
            created_at_ago_fa: '12 دقیقه پیش'
        },
        {
            id: 15,
            title: 'بیوتی مپ',
            description: 'تخفیف ویژه زهرا زارعی تا...',
            created_at_ago_fa: '12 دقیقه پیش'
        },
    ];
});