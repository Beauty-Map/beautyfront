interface ILoginForm {
    phone_number: string
    password: string
    accept_policy: boolean
}