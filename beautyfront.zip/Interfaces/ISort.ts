interface ISort {
    id: number
    title: string
}