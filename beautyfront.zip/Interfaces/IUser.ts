interface IUser {
    id: number
    full_name: string
    phone_number: string
    avatar: string
    has_blue_tick: boolean
}