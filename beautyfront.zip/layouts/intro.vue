<template>
  <div class="intro_page w-full h-screen">
    <slot />
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>